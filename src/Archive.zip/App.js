import React, { Component } from 'react'
import Status from './components/Status'
import Header from './components/Header'
import Paper from './components/Paper'
import Form from './components/Form'
import { deposit, reduce } from './API/api'

class App extends Component {

  state = {
    balance: 100000
  };

  updateBalance = (operation, updatedValue) => {
    if (operation === 'increment') {
      this.setState(deposit(parseInt(updatedValue)));
    } else {
      this.setState(reduce(parseInt(updatedValue)));
    }
  }

  render() {
    return (
      <div className="App">
        <Paper>
          <Header />
          <Status balance={this.state.balance}/>
          <Form updateBalance={this.updateBalance}/>
          
        </Paper>
      </div>
    )
  }
}

export default App
